export class UploadCVClass {
    _id: any
    emailid:any
    file1:any
  }