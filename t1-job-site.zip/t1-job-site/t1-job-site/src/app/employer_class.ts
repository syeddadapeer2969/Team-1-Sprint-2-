export class EmployerClass {
    _id: string='';
    companyname:string=''
    username: string='';
    emailid: string='';
    password: string='';
  address: string='';
  phoneno1: string='';
  phoneno2: string='';
  comments:string='';
  blacklist:boolean=false;
  }