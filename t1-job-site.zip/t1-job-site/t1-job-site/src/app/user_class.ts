export class UserClass {
    _id: string='';
    username: string='';
    emailid: string='';
    password: string='';
  address: string='';
  phoneno1: string='';
  phoneno2: string='';
  comments: any;
  blacklist: any;
  
  }