import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateJobPostedComponent } from './update-job-posted.component';

describe('UpdateJobPostedComponent', () => {
  let component: UpdateJobPostedComponent;
  let fixture: ComponentFixture<UpdateJobPostedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateJobPostedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateJobPostedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
