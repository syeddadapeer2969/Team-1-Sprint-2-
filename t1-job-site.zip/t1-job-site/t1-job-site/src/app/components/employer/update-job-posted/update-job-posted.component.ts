import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { JobPostService } from 'src/app/services/job-post.service';
import { ActivatedRoute, } from '@angular/router';
import { first } from 'rxjs/operators';
@Component({
  selector: 'app-update-job-posted',
  templateUrl: './update-job-posted.component.html',
  styleUrls: ['./update-job-posted.component.css']
})
export class UpdateJobPostedComponent implements OnInit {
  jobname:any
  _id:any
  companyname:any
  jobdescription:any
  minimumexperience:any
  maximumexperience:any
  minimumsalary:any
  maximumsalary:any
  joblocation:any
  noticeperiod:any
  mainskill:any
  subskills:any
  numberofpost:any
  message=''
  constructor(private route: ActivatedRoute, private router: Router,private userService:JobPostService) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this._id = params['_id'];
  })
  this.userService.getJobById(this._id)
  .subscribe( data1 => {
    console.log(data1)
    this.jobname = data1.jobname;
    this.companyname= data1.companyname;
    this.jobdescription  = data1.jobdescription;
    this.minimumexperience = data1.minimumexperience;
    this.maximumexperience=data1.maximumexperience;
    this.minimumsalary=data1.minimumsalary;
    this.maximumsalary=data1.maximumsalary;
    this.joblocation=data1.joblocation;
    this.noticeperiod=data1.noticeperiod;
    this.mainskill=data1.mainskill;
    this.subskills=data1.subskills;
    this.numberofpost=data1.numberofpost;
  },
  error => {
    alert(error);
  }
  );
}

editJob() {
var body = "&_id=" + this._id 
    + "&jobname=" + this.jobname
    + "&companyname=" + this.companyname
    + "&jobdescription=" + this.jobdescription 
    + "&minimumexperience=" + this.minimumexperience
    + "&maximumexperience=" + this.maximumexperience
    + "&minimumsalary=" + this.minimumsalary
    + "&maximumsalary=" + this.maximumsalary
    + "&joblocation=" + this.joblocation
    + "&noticeperiod=" + this.noticeperiod
    + "&mainskill=" + this.mainskill
    + "&subskills=" + this.subskills
    + "&numberofpost=" + this.numberofpost;

this.userService.updateJob(body, this._id)
  .pipe(first())
  .subscribe(
    data => {
      this.router.navigate(['employer-viewJobPost']);
    },
    error => {
      alert(error);
    });
}

}
