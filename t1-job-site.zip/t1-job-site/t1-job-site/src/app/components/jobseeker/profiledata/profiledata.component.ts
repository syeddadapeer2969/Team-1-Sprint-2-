import { Component, OnInit } from '@angular/core';
import {ProfileDataService} from 'src/app/services/profile-data.service';
import {Router} from '@angular/router';
@Component({
  selector: 'app-profiledata',
  templateUrl: './profiledata.component.html',
  styleUrls: ['./profiledata.component.css']
})
export class ProfiledataComponent implements OnInit {

  qualification:any
experience:any
location:any
file:any
resume:any
id:any
  constructor(private router:Router, private userService:ProfileDataService) { }

  ngOnInit(): void {
  }
upload(event:any){
  this.file=event.target.files[0];
}
addUser = () => {
  var body = 
  "&id=" + this.id 
  + "&qualification=" + this.qualification 
  + "&experience" + this.experience
  + "&location=" + this.location
  + "&resume=" + this.resume;
  // + "&pdfSrc=" + this.pdfSrc;
  

this.userService.createUser(body)
.subscribe( data => {
this.router.navigate(['profile']);
alert("registered successfully!!")
}
);

}
 

}
