import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { JobPostService } from 'src/app/services/job-post.service';
import { ApplyForJobService } from 'src/app/services/apply-for-job.service';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
@Component({
  selector: 'app-job-list',
  templateUrl: './job-list.component.html',
  styleUrls: ['./job-list.component.css']
})
export class JobListComponent implements OnInit {
  _id:any
  username:any 
  emailid:any
  phoneno1:any
  phoneno2:any
  qualification:any
  experience:any
  preferredplace:any
  address:any
  approved:any='true'
  
  


  joblists: any[] = []
  total_no_of_records: any
  message = ''
  
  constructor(private empService: JobPostService, private empService1: ApplyForJobService, private router: Router,private commonService:CommonService) { }

  ngOnInit(): void {// Life cycle hooks
    this.username=this.commonService.getusername()
    this.emailid=this.commonService.getemailid()
    this.phoneno1=this.commonService.getphoneno1()
    this.phoneno2=this.commonService.getphoneno2()
    this.qualification=this.commonService.getqualification()
    this.preferredplace=this.commonService.getpreferredplace()
    this.experience= this.commonService.getexperience()
    this._id=this.commonService.get_id()
    this.address=this.commonService.getaddress()
    this.getEmployeeList();
  }

  getEmployeeList = () => {
    this.empService.getJob().subscribe(
      (result) => {
        this.joblists = <any>result;
        this.total_no_of_records = this.joblists.length
      },
      (error) => {
        // console.log(error.name)// HttpErrorResponse, if Backend is not running
        if (error.status === 0 && error.statusText === 'Unknown Error') {
          this.message = 'Backend may be down!'// Backend may not be up and running / HttpErrorResponse
        } else if (error.status === 200 && error.statusText === 'OK') {
          this.message = error.error.text// JWT Error / Any other error
        }
      }
    );

  }

  applyForjob = (jobs: any) => {         

    alert("apply job succesful")
    var body= 
     "jobid=" + jobs._id
      +"&jobname="+ jobs.jobname                                   
      +"&companyname=" + jobs.companyname
      +"&jobdescription="+jobs.jobdescription
      +"&minimumexperience="+jobs.minimumexperience
      +"&maximumexperience="+jobs.maximumexperience
      +"&joblocation="+jobs.joblocation
      +"&noticeperiod="+jobs.noticeperiod
      +"&mainskill="+jobs.mainskill
      +"&subskills="+jobs.subskills
      +"&numberofpost="+jobs.numberofpost
      +"&approved=" + true
      
      +"&username="+this.username
      +"&emailid="+this.emailid
      +"&phoneno1="+this.phoneno1
      +"&phoneno2="+this.phoneno2
      +"&qualification="+this.qualification
      +"&experience="+this.experience
      +"&preferredplace="+this.preferredplace
      +"&address="+this.address
      +"&userid="+this._id
      +"&useridjobid="+this._id+"-"+jobs._id;
    
    // _id:            {type:mongoose.Schema.Types.ObjectId, required:true, auto:true},
    // username:       {type:String, required:true,  unique:false, trim:true},
    // emailid:        {type:String, required:true,  unique:false, trim:true},// Used to get the list Job Applications for a given Job Seeker
    // phoneno1:       {type:String, required:true,  unique:false, trim:true},
    // phoneno2:       {type:String, required:false, unique:false, trim:true},
    // qualification:  {type:String, required:false, unique:false, trim:true},// B.E., M.B.A., / B.Sc., B.Ed.
    // experience:     {type:String, required:false, unique:false, trim:true},// 0 / 2 / 2.5 / 3.75 years
    // preferredplace: {type:String, required:false, unique:false, trim:true}, // let us keep only one place/city
    // jobname:        {type:String, required:true,  unique:false, trim:true},// Angular Developer / Project Manager
    // companyname:    {type:String, required:true,  unique:false, trim:true},// populate from common service
    // joblocation:    {type:String, required:true,  unique:false, trim:true},// keep only one city Chennai / Bangalore / Hydrabad
    // noticeperiod:   {type:String, required:true,  unique:false, trim:true},// Immediate / urgent / 1 month
    // mainskill:      {type:String, required:true,  unique:false, trim:true},// keep only one skill Angular / Node.js / React.js
    // subskills:      {type:String, required:true,  unique:false, trim:true},// HTML, CSS, JavaScript
    // useridjobid:    {type:String, required:true,  unique:true,  trim:true},// User Id - Job Id. Used to avoid 2nd time application
    // jobid:          {type:String, required:true,  unique:false, trim:true},// Job Id // Used to get the list of Job Seekers those who applied for a given Job Posting
    // datetime:       {type:String, required:false, unique:false, trim:true}// syst


    this.empService1.createJob(body)
      .subscribe(data => {
        // this.router.navigate(['userlist']);
        this.router.navigate(['jobseekerdas']);
      },
        (error) => {
          this.message = error.error
        });
  }



}



