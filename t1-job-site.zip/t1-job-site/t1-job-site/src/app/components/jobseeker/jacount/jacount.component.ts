import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jacount',
  templateUrl: './jacount.component.html',
  styleUrls: ['./jacount.component.css']
})
export class JacountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
