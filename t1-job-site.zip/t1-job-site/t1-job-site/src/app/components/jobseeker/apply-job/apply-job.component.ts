import { NgStyle } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApplyForJobService } from 'src/app/services/apply-for-job.service';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-apply-job',
  templateUrl: './apply-job.component.html',
  styleUrls: ['./apply-job.component.css']
})
export class ApplyJobComponent implements OnInit {

  username:any
emailid:any
phoneno1:any
phoneno2:any
qualification:any
preferredplace:any
experience:any
jobname:any
companyname:any
joblocation:any
noticeperiod:any
mainskill:any
subskills:any
useridjobid:any
jobid:any
_id:any
  constructor(private router:Router, private applyService:ApplyForJobService , private commonService:CommonService) {
    this.companyname=this.commonService.getcompanyname()
   }

  ngOnInit(): void {
  }

  addForJob = () => {
  var body = 
  // "&_id=" + this._id
   "username=" + this.username
  + "&emailid=" + this.emailid
  + "&phoneno1=" + this.phoneno1
  + "&phoneno2=" + this.phoneno2
  + "&qualification=" + this.qualification 
  + "&experience" + this.experience
  + "&preferredplace=" + this.preferredplace
  + "&jobname=" + this.jobname
  + "&companyname=" + this.commonService.getcompanyname()
  + "&joblocation=" + this.joblocation
  + "&noticeperiod=" + this.noticeperiod
  + "&mainskill=" + this.mainskill
  + "&subskills=" + this.subskills
  + "&useridjobid=" + this.useridjobid
  + "&jobid=" + this.jobid;
  // + "&pdfSrc=" + this.pdfSrc;
  

// this.applyService.createUser(body)
// .subscribe( data => {
// this.router.navigate(['jobseekerdas']);
// alert("Profile data is added successfully!!")
// }


}

}
