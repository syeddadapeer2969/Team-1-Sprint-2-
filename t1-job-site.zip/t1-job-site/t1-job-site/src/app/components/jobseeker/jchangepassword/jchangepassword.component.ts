import { Component, OnInit } from '@angular/core';
import {UserService} from 'src/app/services/user.service';
import { ActivatedRoute, Router } from '@angular/router';
import { first } from 'rxjs/operators';
@Component({
  selector: 'app-jchangepassword',
  templateUrl: './jchangepassword.component.html',
  styleUrls: ['./jchangepassword.component.css']
})
export class JchangepasswordComponent implements OnInit {
  _id:any
  old_password:any
  new_password:any
  confirm_new_password:any
  password:any
  
  constructor(private route: ActivatedRoute, private router: Router, private userService:UserService) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this._id = params['_id'];
  })
  this.userService.getUserById(this._id)
      .subscribe( data1 => {
        console.log(data1)
        this.password = data1.password;
      },
      error => {
        alert(error);
      }
      );
    }

  editEmployee() {
    var body =  
        + "&password=" + this.password;
        
    this.userService.updateUser(body, this._id)
      .pipe(first())
      .subscribe(
        data => {
          this.router.navigate(['jobseekerdas']);
        },
        error => {
          alert(error);
        });
  }
}
