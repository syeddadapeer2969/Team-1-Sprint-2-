import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-heaser',
  templateUrl: './heaser.component.html',
  styleUrls: ['./heaser.component.css']
})
export class HeaserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
