import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sitelayout',
  templateUrl: './sitelayout.component.html',
  styleUrls: ['./sitelayout.component.css']
})
export class SitelayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
