import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alogin',
  templateUrl: './alogin.component.html',
  styleUrls: ['./alogin.component.css']
})
export class AloginComponent implements OnInit {

emailid:any
  password:any
hide=true;
  constructor() { }

  login = () =>{
    let obj={ email_id : this.emailid, pass_word: this.password}
    console.log(obj);
  }
  // constructor() { }

  ngOnInit(): void {
  }

}
