import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BlockCommentUserComponent } from './block-comment-user.component';

describe('BlockCommentUserComponent', () => {
  let component: BlockCommentUserComponent;
  let fixture: ComponentFixture<BlockCommentUserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BlockCommentUserComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BlockCommentUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
