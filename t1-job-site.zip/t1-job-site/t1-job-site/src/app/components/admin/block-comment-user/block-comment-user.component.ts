import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-block-comment-user',
  templateUrl: './block-comment-user.component.html',
  styleUrls: ['./block-comment-user.component.css']
})
export class BlockCommentUserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
